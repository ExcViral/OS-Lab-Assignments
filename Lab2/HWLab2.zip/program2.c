#include<unistd.h>
#include<stdio.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<stdlib.h>
int main ()
{
pid_t k;
int sum;
int p[9] = {1,2,3,4,5,6,7,8,9};
k=fork();
if(k==0)
{
k=fork();
if(k==0)
{
int a=p[0]+p[1]+p[2];
exit(a);
 }
else
{
int b;
wait(&b);
b=WEXITSTATUS(b);
b+=p[3]+p[4]+p[5];
exit(b);
}
}
else
{
int c;
wait(&c);
c=WEXITSTATUS(c);
c+=p[6]+p[7]+p[8];
printf("ans=%d",c);
printf("\n");
}
}
